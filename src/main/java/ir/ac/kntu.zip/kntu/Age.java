package ir.ac.kntu;

public enum Age {
    CHILD,ADOLESCENT,ADULT;
}
