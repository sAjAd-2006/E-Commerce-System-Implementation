package ir.ac.kntu;

public enum Report {
    Product_qualit,Discrepancy_between_order_and_delivered_product,Settings,Not_receiving_order,ALL;
}
