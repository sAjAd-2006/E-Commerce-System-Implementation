package ir.ac.kntu;

public enum Check {
    Registered,Pending,Closed,ALL;
}
