package ir.ac.kntu;

public enum Model {
    MOBILE,LAPTOP,BOOK;
}
