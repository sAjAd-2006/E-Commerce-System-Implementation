package ir.ac.kntu;

public enum Type {
    DIGITALGOODS,BOOK;
}
